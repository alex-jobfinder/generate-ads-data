import dearpygui.dearpygui as dpg
import os

# Set environment variables for WSL2 compatibility
os.environ['DISPLAY'] = ':0'
os.environ['LIBGL_ALWAYS_INDIRECT'] = '1'
os.environ['MESA_GL_VERSION_OVERRIDE'] = '3.3'

try:
    print("Creating context...")
    dpg.create_context()
    
    print("Creating viewport...")
    dpg.create_viewport(title='Minimal Test', width=400, height=300)
    
    print("Creating window...")
    with dpg.window(label="Test Window", width=300, height=200):
        dpg.add_text("Hello from DearPyGui!")
        dpg.add_button(label="Click me", callback=lambda: print("Button clicked!"))
    
    print("Setting up DearPyGui...")
    dpg.setup_dearpygui()
    
    print("Showing viewport...")
    dpg.show_viewport()
    
    print("Starting DearPyGui...")
    dpg.start_dearpygui()
    
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
finally:
    print("Destroying context...")
    dpg.destroy_context()