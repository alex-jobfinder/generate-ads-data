#!/usr/bin/env python3
"""
Minimal DearPyGui test to isolate the WSL2 issue.
"""

import dearpygui.dearpygui as dpg
import os
import sys

# Set environment variables
os.environ['DISPLAY'] = ':0'

print("Starting minimal DearPyGui test...")

try:
    print("1. Creating context...")
    dpg.create_context()
    
    print("2. Creating viewport...")
    dpg.create_viewport(title='Minimal Test', width=400, height=300)
    
    print("3. Creating window...")
    with dpg.window(label="Test Window", width=300, height=200):
        dpg.add_text("Hello from DearPyGui!")
    
    print("4. Setting up DearPyGui...")
    dpg.setup_dearpygui()
    
    print("5. Showing viewport...")
    dpg.show_viewport()
    
    print("6. Starting DearPyGui main loop...")
    dpg.start_dearpygui()
    
    print("7. Main loop ended, destroying context...")
    
except Exception as e:
    print(f"Error at step: {e}")
    import traceback
    traceback.print_exc()
finally:
    print("8. Final cleanup...")
    dpg.destroy_context()
    print("Test completed.")
