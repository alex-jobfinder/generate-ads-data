import dearpygui.dearpygui as dpg
import dearpygui.demo as demo
import os

# Set environment variables for WSL2 compatibility
os.environ['LIBGL_ALWAYS_INDIRECT'] = '1'
os.environ['MESA_GL_VERSION_OVERRIDE'] = '3.3'

try:
    dpg.create_context()
    dpg.create_viewport(title='Custom Title', width=600, height=600)
    
    demo.show_demo()
    
    dpg.setup_dearpygui()
    dpg.show_viewport()
    dpg.start_dearpygui()
    
except Exception as e:
    print(f"Error: {e}")
    print("This is a known issue with DearPyGui on WSL2.")
    print("Try running the script on Windows native Python instead.")
finally:
    dpg.destroy_context()
