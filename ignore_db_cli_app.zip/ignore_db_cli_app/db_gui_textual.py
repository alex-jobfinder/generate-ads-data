#!/usr/bin/env python3
import sys
import os
from typing import Optional

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cli_groups.db import cb_init_db, cb_migrate_db

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Button, Input, Select, Static, TextArea, Header, Footer
)
from textual.reactive import reactive


class DBGUI(App):
    CSS = """
    Screen {
        layout: vertical;
    }
    
    .settings {
        height: 8;
        border: solid $primary;
        margin: 1;
        padding: 1;
    }
    
    .buttons {
        height: 3;
        border: solid $primary;
        margin: 1;
        padding: 1;
    }
    
    .log {
        border: solid $primary;
        margin: 1;
        padding: 1;
    }
    
    Button {
        margin: 1;
    }
    
    Input {
        margin: 1;
    }
    
    Select {
        margin: 1;
    }
    """
    
    # Reactive variables
    db_url = reactive("sqlite:///ads.db")
    log_level = reactive("INFO")
    seed = reactive(42)
    log_output = reactive("🚀 Database Operations GUI ready\n")
    
    def compose(self) -> ComposeResult:
        yield Header()
        
        with Container(classes="settings"):
            yield Static("Database Settings", classes="title")
            yield Input(
                placeholder="Database URL",
                value=self.db_url,
                id="db_url"
            )
            yield Select(
                options=[("DEBUG", "DEBUG"), ("INFO", "INFO"), ("WARNING", "WARNING"), ("ERROR", "ERROR")],
                value=self.log_level,
                id="log_level"
            )
            yield Input(
                placeholder="Seed",
                value=str(self.seed),
                id="seed"
            )
        
        with Container(classes="buttons"):
            yield Static("Database Operations", classes="title")
            with Horizontal():
                yield Button("Initialize Database", id="init_db", variant="primary")
                yield Button("Migrate Database", id="migrate_db", variant="success")
        
        with Container(classes="log"):
            yield Static("Output Log", classes="title")
            yield TextArea(
                self.log_output,
                id="log_area",
                read_only=True
            )
        
        yield Footer()
    
    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input changes."""
        if event.input.id == "db_url":
            self.db_url = event.value
        elif event.input.id == "seed":
            try:
                self.seed = int(event.value)
            except ValueError:
                pass
    
    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select changes."""
        if event.select.id == "log_level":
            self.log_level = event.value
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "init_db":
            self.init_database()
        elif event.button.id == "migrate_db":
            self.migrate_database()
    
    def log_message(self, message: str) -> None:
        """Add a message to the log."""
        self.log_output += f"{message}\n"
        log_area = self.query_one("#log_area", TextArea)
        log_area.text = self.log_output
        log_area.scroll_end()
    
    def init_database(self) -> None:
        """Initialize the database."""
        try:
            self.log_message("🔄 Initializing database...")
            self.log_message(f"   URL: {self.db_url}")
            self.log_message(f"   Log Level: {self.log_level}")
            self.log_message(f"   Seed: {self.seed}")
            
            cb_init_db(
                log_level=self.log_level,
                db_url=self.db_url,
                seed=self.seed
            )
            
            self.log_message("✅ Database initialized successfully!")
            
        except Exception as e:
            self.log_message(f"❌ Error initializing database: {str(e)}")
    
    def migrate_database(self) -> None:
        """Migrate the database."""
        try:
            self.log_message(" Migrating database...")
            self.log_message(f"   URL: {self.db_url}")
            self.log_message(f"   Log Level: {self.log_level}")
            
            cb_migrate_db(
                log_level=self.log_level,
                db_url=self.db_url
            )
            
            self.log_message("✅ Database migrated successfully!")
            
        except Exception as e:
            self.log_message(f"❌ Error migrating database: {str(e)}")


if __name__ == "__main__":
    app = DBGUI()
    app.run()