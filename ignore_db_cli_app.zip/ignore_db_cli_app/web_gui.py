#!/usr/bin/env python3
"""
Web-based GUI for CLI commands: init db and create advertiser.

This provides a web interface that works in any browser, perfect for WSL2
environments where X11/GUI support is not available.

Usage:
    python web_gui.py
    Then open http://localhost:8080 in your browser
"""

import sys
import os
import json
from typing import Optional, Dict, Any
from datetime import datetime

# Add the project root to the path so we can import CLI modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from flask import Flask, render_template_string, request, jsonify
    from flask_cors import CORS
except ImportError:
    print("❌ Flask not installed. Installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "flask-cors"])
    from flask import Flask, render_template_string, request, jsonify
    from flask_cors import CORS

# Import the CLI callback functions
from cli_groups.db import cb_init_db
from cli_groups.campaign import cb_create_advertiser


app = Flask(__name__)
CORS(app)

# Store operation logs
operation_logs = []


def log_operation(operation: str, status: str, message: str, details: Optional[Dict] = None):
    """Log an operation for display in the web interface."""
    log_entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "operation": operation,
        "status": status,
        "message": message,
        "details": details or {}
    }
    operation_logs.append(log_entry)
    # Keep only last 50 logs
    if len(operation_logs) > 50:
        operation_logs.pop(0)


# HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CLI Web GUI - Database & Advertiser Manager</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 1.1em;
        }
        
        .content {
            padding: 30px;
        }
        
        .section {
            margin-bottom: 40px;
            border: 1px solid #e1e8ed;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .section-header {
            background: #f8f9fa;
            padding: 20px;
            border-bottom: 1px solid #e1e8ed;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .section-header:hover {
            background: #e9ecef;
        }
        
        .section-header h2 {
            color: #2c3e50;
            font-size: 1.3em;
        }
        
        .section-content {
            padding: 25px;
            display: none;
        }
        
        .section-content.active {
            display: block;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e8ed;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: auto;
        }
        
        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .btn-secondary {
            background: #6c757d;
        }
        
        .btn-secondary:hover {
            box-shadow: 0 5px 15px rgba(108, 117, 125, 0.4);
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .log-container {
            background: #f8f9fa;
            border: 1px solid #e1e8ed;
            border-radius: 8px;
            padding: 20px;
            max-height: 300px;
            overflow-y: auto;
        }
        
        .log-entry {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border-left: 4px solid #ddd;
        }
        
        .log-entry.success {
            background: #d4edda;
            border-left-color: #28a745;
        }
        
        .log-entry.error {
            background: #f8d7da;
            border-left-color: #dc3545;
        }
        
        .log-entry.info {
            background: #d1ecf1;
            border-left-color: #17a2b8;
        }
        
        .log-timestamp {
            font-size: 0.8em;
            color: #6c757d;
            margin-right: 10px;
        }
        
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
        
        .status-success { background: #28a745; }
        .status-error { background: #dc3545; }
        .status-info { background: #17a2b8; }
        
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }
        
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            border-left: 4px solid;
        }
        
        .alert-info {
            background: #d1ecf1;
            border-left-color: #17a2b8;
            color: #0c5460;
        }
        
        .alert-success {
            background: #d4edda;
            border-left-color: #28a745;
            color: #155724;
        }
        
        .alert-error {
            background: #f8d7da;
            border-left-color: #dc3545;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🚀 CLI Web GUI</h1>
            <p>Database & Advertiser Manager - Works in WSL2!</p>
        </div>
        
        <div class="content">
            <div class="alert alert-info">
                <strong>💡 WSL2 Compatible:</strong> This web interface works perfectly in WSL2 environments without X11 setup.
            </div>
            
            <!-- Database Section -->
            <div class="section">
                <div class="section-header" onclick="toggleSection('database')">
                    <h2>🗄️ Database Operations</h2>
                    <span>▼</span>
                </div>
                <div class="section-content active" id="database">
                    <h3>Initialize Database</h3>
                    <form id="dbForm">
                        <div class="form-group">
                            <label for="dbUrl">Database URL:</label>
                            <input type="text" id="dbUrl" name="dbUrl" value="sqlite:///ads.db">
                        </div>
                        <div class="form-group">
                            <label for="logLevel">Log Level:</label>
                            <select id="logLevel" name="logLevel">
                                <option value="DEBUG">DEBUG</option>
                                <option value="INFO" selected>INFO</option>
                                <option value="WARNING">WARNING</option>
                                <option value="ERROR">ERROR</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="seed">Seed:</label>
                            <input type="number" id="seed" name="seed" value="42">
                        </div>
                        <div class="btn-group">
                            <button type="submit" class="btn">Initialize Database</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Advertiser Section -->
            <div class="section">
                <div class="section-header" onclick="toggleSection('advertiser')">
                    <h2>👤 Advertiser Operations</h2>
                    <span>▼</span>
                </div>
                <div class="section-content" id="advertiser">
                    <h3>Create Advertiser</h3>
                    <form id="advertiserForm">
                        <div class="form-group">
                            <div class="checkbox-group">
                                <input type="checkbox" id="autoGenerate" name="autoGenerate">
                                <label for="autoGenerate">Auto-generate advertiser data</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="advertiserName">Name:</label>
                            <input type="text" id="advertiserName" name="advertiserName">
                        </div>
                        <div class="form-group">
                            <label for="advertiserEmail">Email:</label>
                            <input type="email" id="advertiserEmail" name="advertiserEmail">
                        </div>
                        <div class="form-group">
                            <label for="advertiserBrand">Brand (optional):</label>
                            <input type="text" id="advertiserBrand" name="advertiserBrand">
                        </div>
                        <div class="form-group">
                            <label for="advertiserAgency">Agency (optional):</label>
                            <input type="text" id="advertiserAgency" name="advertiserAgency">
                        </div>
                        <div class="btn-group">
                            <button type="submit" class="btn">Create Advertiser</button>
                            <button type="button" class="btn btn-secondary" onclick="clearAdvertiserForm()">Clear Form</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Log Section -->
            <div class="section">
                <div class="section-header" onclick="toggleSection('logs')">
                    <h2>📋 Operation Logs</h2>
                    <span>▼</span>
                </div>
                <div class="section-content" id="logs">
                    <div class="btn-group">
                        <button class="btn btn-secondary" onclick="clearLogs()">Clear Logs</button>
                        <button class="btn btn-secondary" onclick="refreshLogs()">Refresh</button>
                    </div>
                    <div class="log-container" id="logContainer">
                        <div class="log-entry info">
                            <span class="log-timestamp">Ready</span>
                            <span class="status-indicator status-info"></span>
                            Web GUI started successfully
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p>Processing...</p>
            </div>
        </div>
    </div>

    <script>
        function toggleSection(sectionId) {
            const content = document.getElementById(sectionId);
            const isActive = content.classList.contains('active');
            
            // Close all sections
            document.querySelectorAll('.section-content').forEach(s => s.classList.remove('active'));
            
            // Open clicked section if it wasn't active
            if (!isActive) {
                content.classList.add('active');
            }
        }
        
        function showLoading() {
            document.getElementById('loading').style.display = 'block';
        }
        
        function hideLoading() {
            document.getElementById('loading').style.display = 'none';
        }
        
        function addLogEntry(entry) {
            const container = document.getElementById('logContainer');
            const logEntry = document.createElement('div');
            logEntry.className = `log-entry ${entry.status}`;
            
            const statusClass = entry.status === 'success' ? 'status-success' : 
                              entry.status === 'error' ? 'status-error' : 'status-info';
            
            logEntry.innerHTML = `
                <span class="log-timestamp">${entry.timestamp}</span>
                <span class="status-indicator ${statusClass}"></span>
                <strong>${entry.operation}:</strong> ${entry.message}
            `;
            
            container.insertBefore(logEntry, container.firstChild);
            
            // Keep only last 20 entries visible
            while (container.children.length > 20) {
                container.removeChild(container.lastChild);
            }
        }
        
        function clearLogs() {
            document.getElementById('logContainer').innerHTML = '';
        }
        
        function refreshLogs() {
            fetch('/api/logs')
                .then(response => response.json())
                .then(logs => {
                    const container = document.getElementById('logContainer');
                    container.innerHTML = '';
                    logs.reverse().forEach(log => addLogEntry(log));
                });
        }
        
        function clearAdvertiserForm() {
            document.getElementById('advertiserForm').reset();
        }
        
        // Database form submission
        document.getElementById('dbForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading();
            
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            try {
                const response = await fetch('/api/init-db', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                addLogEntry(result);
            } catch (error) {
                addLogEntry({
                    timestamp: new Date().toLocaleTimeString(),
                    operation: 'Database Init',
                    status: 'error',
                    message: error.message
                });
            } finally {
                hideLoading();
            }
        });
        
        // Advertiser form submission
        document.getElementById('advertiserForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading();
            
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            data.autoGenerate = document.getElementById('autoGenerate').checked;
            
            try {
                const response = await fetch('/api/create-advertiser', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                addLogEntry(result);
                
                if (data.autoGenerate) {
                    clearAdvertiserForm();
                }
            } catch (error) {
                addLogEntry({
                    timestamp: new Date().toLocaleTimeString(),
                    operation: 'Create Advertiser',
                    status: 'error',
                    message: error.message
                });
            } finally {
                hideLoading();
            }
        });
        
        // Load initial logs
        refreshLogs();
    </script>
</body>
</html>
"""


@app.route('/')
def index():
    """Serve the main web interface."""
    return render_template_string(HTML_TEMPLATE)


@app.route('/api/init-db', methods=['POST'])
def api_init_db():
    """Initialize database API endpoint."""
    try:
        data = request.get_json()
        
        # Call the CLI callback function
        cb_init_db(
            log_level=data.get('logLevel'),
            db_url=data.get('dbUrl'),
            seed=int(data.get('seed', 42))
        )
        
        log_operation(
            "Database Init",
            "success",
            "Database initialized successfully!",
            {"db_url": data.get('dbUrl'), "log_level": data.get('logLevel')}
        )
        
        return jsonify({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "operation": "Database Init",
            "status": "success",
            "message": "Database initialized successfully!"
        })
        
    except Exception as e:
        log_operation(
            "Database Init",
            "error",
            f"Error: {str(e)}"
        )
        
        return jsonify({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "operation": "Database Init",
            "status": "error",
            "message": f"Error: {str(e)}"
        }), 500


@app.route('/api/create-advertiser', methods=['POST'])
def api_create_advertiser():
    """Create advertiser API endpoint."""
    try:
        data = request.get_json()
        
        # Prepare parameters
        name = data.get('advertiserName') if data.get('advertiserName', '').strip() else None
        email = data.get('advertiserEmail') if data.get('advertiserEmail', '').strip() else None
        brand = data.get('advertiserBrand') if data.get('advertiserBrand', '').strip() else None
        agency = data.get('advertiserAgency') if data.get('advertiserAgency', '').strip() else None
        
        # Call the CLI callback function
        cb_create_advertiser(
            name=name,
            email=email,
            brand=brand,
            agency=agency,
            auto=data.get('autoGenerate', False),
            log_level="INFO",
            db_url="sqlite:///ads.db",
            seed=42
        )
        
        log_operation(
            "Create Advertiser",
            "success",
            "Advertiser created successfully!",
            {"name": name, "email": email, "auto": data.get('autoGenerate', False)}
        )
        
        return jsonify({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "operation": "Create Advertiser",
            "status": "success",
            "message": "Advertiser created successfully!"
        })
        
    except Exception as e:
        log_operation(
            "Create Advertiser",
            "error",
            f"Error: {str(e)}"
        )
        
        return jsonify({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "operation": "Create Advertiser",
            "status": "error",
            "message": f"Error: {str(e)}"
        }), 500


@app.route('/api/logs')
def api_logs():
    """Get operation logs API endpoint."""
    return jsonify(operation_logs)


def main():
    """Main entry point."""
    print("🌐 Starting CLI Web GUI...")
    print("📱 Open your browser and go to: http://localhost:8080")
    print("💡 This works perfectly in WSL2 without X11 setup!")
    print("🛑 Press Ctrl+C to stop the server")
    
    # Add initial log entry
    log_operation(
        "Web GUI",
        "info",
        "Web GUI started successfully - WSL2 compatible!"
    )
    
    try:
        app.run(host='0.0.0.0', port=8080, debug=False)
    except KeyboardInterrupt:
        print("\n👋 Web GUI stopped")


if __name__ == "__main__":
    main()
