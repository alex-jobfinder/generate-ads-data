#!/usr/bin/env python3
"""
Simple DearPyGui application for CLI commands: init db and create advertiser.

This provides a GUI interface for the two most common CLI operations:
1. Initialize database
2. Create advertiser

Usage:
    python gui_app.py
"""

import dearpygui.dearpygui as dpg
import sys
import os
from typing import Optional

# Add the project root to the path so we can import CLI modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the CLI callback functions
from cli_groups.db import cb_init_db
from cli_groups.campaign import cb_create_advertiser


class CLIApp:
    """Simple GUI application for CLI commands."""
    
    def __init__(self):
        self.db_url = "sqlite:///ads.db"
        self.log_level = "INFO"
        self.seed = 42
        
        # Advertiser fields
        self.advertiser_name = ""
        self.advertiser_email = ""
        self.advertiser_brand = ""
        self.advertiser_agency = ""
        self.auto_generate = False
        
        # Output log
        self.output_log = []
    
    def log_message(self, message: str):
        """Add a message to the output log."""
        self.output_log.append(message)
        if len(self.output_log) > 100:  # Keep only last 100 messages
            self.output_log.pop(0)
        
        # Update the log display
        if dpg.does_item_exist("output_log"):
            dpg.set_value("output_log", "\n".join(self.output_log))
            dpg.set_item_scroll_y("output_log", -1)  # Scroll to bottom
    
    def init_database(self):
        """Initialize the database using CLI callback."""
        try:
            self.log_message("🔄 Initializing database...")
            
            # Call the CLI callback function
            cb_init_db(
                log_level=self.log_level,
                db_url=self.db_url,
                seed=self.seed
            )
            
            self.log_message("✅ Database initialized successfully!")
            
        except Exception as e:
            self.log_message(f"❌ Error initializing database: {str(e)}")
    
    def create_advertiser(self):
        """Create an advertiser using CLI callback."""
        try:
            self.log_message("🔄 Creating advertiser...")
            
            # Prepare parameters
            name = self.advertiser_name if self.advertiser_name.strip() else None
            email = self.advertiser_email if self.advertiser_email.strip() else None
            brand = self.advertiser_brand if self.advertiser_brand.strip() else None
            agency = self.advertiser_agency if self.advertiser_agency.strip() else None
            
            # Call the CLI callback function
            cb_create_advertiser(
                name=name,
                email=email,
                brand=brand,
                agency=agency,
                auto=self.auto_generate,
                log_level=self.log_level,
                db_url=self.db_url,
                seed=self.seed
            )
            
            self.log_message("✅ Advertiser created successfully!")
            
            # Clear form if auto-generate was used
            if self.auto_generate:
                self.clear_advertiser_form()
            
        except Exception as e:
            self.log_message(f"❌ Error creating advertiser: {str(e)}")
    
    def clear_advertiser_form(self):
        """Clear the advertiser form fields."""
        dpg.set_value("advertiser_name", "")
        dpg.set_value("advertiser_email", "")
        dpg.set_value("advertiser_brand", "")
        dpg.set_value("advertiser_agency", "")
        dpg.set_value("auto_generate", False)
        
        self.advertiser_name = ""
        self.advertiser_email = ""
        self.advertiser_brand = ""
        self.advertiser_agency = ""
        self.auto_generate = False
    
    def create_gui(self):
        """Create the GUI interface."""
        dpg.create_context()
        dpg.create_viewport(title="CLI GUI - Database & Advertiser Manager", width=800, height=600)
        
        with dpg.window(label="Main Window", tag="main_window"):
            dpg.add_text("CLI GUI - Database & Advertiser Manager", bullet=True)
            dpg.add_separator()
            
            # Database Section
            with dpg.collapsing_header(label="🗄️ Database Operations", default_open=True):
                dpg.add_text("Initialize Database")
                dpg.add_input_text(
                    label="Database URL",
                    default_value=self.db_url,
                    tag="db_url",
                    callback=lambda s, a: setattr(self, 'db_url', a)
                )
                dpg.add_combo(
                    label="Log Level",
                    items=["DEBUG", "INFO", "WARNING", "ERROR"],
                    default_value=self.log_level,
                    tag="log_level",
                    callback=lambda s, a: setattr(self, 'log_level', a)
                )
                dpg.add_input_int(
                    label="Seed",
                    default_value=self.seed,
                    tag="seed",
                    callback=lambda s, a: setattr(self, 'seed', a)
                )
                dpg.add_button(
                    label="Initialize Database",
                    callback=self.init_database,
                    width=200
                )
            
            dpg.add_separator()
            
            # Advertiser Section
            with dpg.collapsing_header(label="👤 Advertiser Operations", default_open=True):
                dpg.add_text("Create Advertiser")
                
                dpg.add_checkbox(
                    label="Auto-generate advertiser data",
                    tag="auto_generate",
                    callback=lambda s, a: setattr(self, 'auto_generate', a)
                )
                
                dpg.add_input_text(
                    label="Name",
                    tag="advertiser_name",
                    callback=lambda s, a: setattr(self, 'advertiser_name', a)
                )
                dpg.add_input_text(
                    label="Email",
                    tag="advertiser_email",
                    callback=lambda s, a: setattr(self, 'advertiser_email', a)
                )
                dpg.add_input_text(
                    label="Brand (optional)",
                    tag="advertiser_brand",
                    callback=lambda s, a: setattr(self, 'advertiser_brand', a)
                )
                dpg.add_input_text(
                    label="Agency (optional)",
                    tag="advertiser_agency",
                    callback=lambda s, a: setattr(self, 'advertiser_agency', a)
                )
                
                dpg.add_button(
                    label="Create Advertiser",
                    callback=self.create_advertiser,
                    width=200
                )
                dpg.add_same_line()
                dpg.add_button(
                    label="Clear Form",
                    callback=self.clear_advertiser_form,
                    width=100
                )
            
            dpg.add_separator()
            
            # Output Log Section
            with dpg.collapsing_header(label="📋 Output Log", default_open=True):
                dpg.add_input_text(
                    label="Log",
                    multiline=True,
                    height=200,
                    readonly=True,
                    tag="output_log"
                )
                dpg.add_button(
                    label="Clear Log",
                    callback=lambda: (self.output_log.clear(), dpg.set_value("output_log", "")),
                    width=100
                )
        
        dpg.setup_dearpygui()
        dpg.show_viewport()
        dpg.set_primary_window("main_window", True)
    
    def run(self):
        """Run the GUI application."""
        self.create_gui()
        
        # Initial log message
        self.log_message("🚀 CLI GUI Application started")
        self.log_message("💡 Use the sections above to initialize database and create advertisers")
        
        # Main loop
        while dpg.is_dearpygui_running():
            dpg.render_dearpygui_frame()
        
        dpg.destroy_context()


def main():
    """Main entry point."""
    try:
        app = CLIApp()
        app.run()
    except ImportError as e:
        print("❌ Error: DearPyGui not installed")
        print("💡 Install it with: pip install dearpygui")
        print(f"   Import error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error starting GUI application: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

"""
export DISPLAY=:0 && python gui_app.py
"""