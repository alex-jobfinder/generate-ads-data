#!/usr/bin/env python3
"""
Tkinter-based GUI for CLI commands: init db and create advertiser.

This provides a native GUI interface that works perfectly with VcXsrv in WSL2.

Usage:
    python tkinter_gui.py
"""

import sys
import os
import json
import threading
from typing import Optional
from datetime import datetime

# Add the project root to the path so we can import CLI modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
except ImportError:
    print("❌ Tkinter not available. Please install python3-tk:")
    print("   sudo apt install python3-tk")
    sys.exit(1)

# Import the CLI callback functions
from cli_groups.db import cb_init_db
from cli_groups.campaign import cb_create_advertiser


class CLIGUI:
    """Main GUI application class."""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("CLI GUI - Database & Advertiser Manager")
        self.root.geometry("800x700")
        self.root.configure(bg='#f0f0f0')
        
        # Variables
        self.db_url = tk.StringVar(value="sqlite:///ads.db")
        self.log_level = tk.StringVar(value="INFO")
        self.seed = tk.IntVar(value=42)
        
        self.advertiser_name = tk.StringVar()
        self.advertiser_email = tk.StringVar()
        self.advertiser_brand = tk.StringVar()
        self.advertiser_agency = tk.StringVar()
        self.auto_generate = tk.BooleanVar()
        
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the user interface."""
        # Main title
        title_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        title_frame.pack(fill='x', padx=10, pady=10)
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(
            title_frame, 
            text="🚀 CLI GUI - Database & Advertiser Manager", 
            font=('Arial', 16, 'bold'),
            fg='white',
            bg='#2c3e50'
        )
        title_label.pack(expand=True)
        
        subtitle_label = tk.Label(
            title_frame,
            text="WSL2 + VcXsrv Compatible",
            font=('Arial', 10),
            fg='#bdc3c7',
            bg='#2c3e50'
        )
        subtitle_label.pack()
        
        # Create notebook for tabs
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Database tab
        self.setup_database_tab(notebook)
        
        # Advertiser tab
        self.setup_advertiser_tab(notebook)
        
        # Log tab
        self.setup_log_tab(notebook)
        
    def setup_database_tab(self, notebook):
        """Set up the database operations tab."""
        db_frame = ttk.Frame(notebook)
        notebook.add(db_frame, text="🗄️ Database")
        
        # Database section
        db_section = tk.LabelFrame(db_frame, text="Initialize Database", font=('Arial', 12, 'bold'))
        db_section.pack(fill='x', padx=10, pady=10)
        
        # Database URL
        tk.Label(db_section, text="Database URL:").grid(row=0, column=0, sticky='w', padx=5, pady=5)
        tk.Entry(db_section, textvariable=self.db_url, width=50).grid(row=0, column=1, padx=5, pady=5)
        
        # Log Level
        tk.Label(db_section, text="Log Level:").grid(row=1, column=0, sticky='w', padx=5, pady=5)
        log_combo = ttk.Combobox(db_section, textvariable=self.log_level, values=["DEBUG", "INFO", "WARNING", "ERROR"])
        log_combo.grid(row=1, column=1, sticky='w', padx=5, pady=5)
        
        # Seed
        tk.Label(db_section, text="Seed:").grid(row=2, column=0, sticky='w', padx=5, pady=5)
        tk.Entry(db_section, textvariable=self.seed, width=10).grid(row=2, column=1, sticky='w', padx=5, pady=5)
        
        # Buttons
        button_frame = tk.Frame(db_section)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)
        
        tk.Button(
            button_frame, 
            text="Initialize Database", 
            command=self.init_database,
            bg='#3498db',
            fg='white',
            font=('Arial', 10, 'bold'),
            padx=20,
            pady=5
        ).pack(side='left', padx=5)
        
    def setup_advertiser_tab(self, notebook):
        """Set up the advertiser operations tab."""
        adv_frame = ttk.Frame(notebook)
        notebook.add(adv_frame, text="👤 Advertiser")
        
        # Advertiser section
        adv_section = tk.LabelFrame(adv_frame, text="Create Advertiser", font=('Arial', 12, 'bold'))
        adv_section.pack(fill='x', padx=10, pady=10)
        
        # Auto-generate checkbox
        tk.Checkbutton(
            adv_section, 
            text="Auto-generate advertiser data", 
            variable=self.auto_generate,
            command=self.toggle_auto_generate
        ).grid(row=0, column=0, columnspan=2, sticky='w', padx=5, pady=5)
        
        # Name
        tk.Label(adv_section, text="Name:").grid(row=1, column=0, sticky='w', padx=5, pady=5)
        self.name_entry = tk.Entry(adv_section, textvariable=self.advertiser_name, width=40)
        self.name_entry.grid(row=1, column=1, padx=5, pady=5)
        
        # Email
        tk.Label(adv_section, text="Email:").grid(row=2, column=0, sticky='w', padx=5, pady=5)
        self.email_entry = tk.Entry(adv_section, textvariable=self.advertiser_email, width=40)
        self.email_entry.grid(row=2, column=1, padx=5, pady=5)
        
        # Brand
        tk.Label(adv_section, text="Brand (optional):").grid(row=3, column=0, sticky='w', padx=5, pady=5)
        self.brand_entry = tk.Entry(adv_section, textvariable=self.advertiser_brand, width=40)
        self.brand_entry.grid(row=3, column=1, padx=5, pady=5)
        
        # Agency
        tk.Label(adv_section, text="Agency (optional):").grid(row=4, column=0, sticky='w', padx=5, pady=5)
        self.agency_entry = tk.Entry(adv_section, textvariable=self.advertiser_agency, width=40)
        self.agency_entry.grid(row=4, column=1, padx=5, pady=5)
        
        # Buttons
        button_frame = tk.Frame(adv_section)
        button_frame.grid(row=5, column=0, columnspan=2, pady=10)
        
        tk.Button(
            button_frame, 
            text="Create Advertiser", 
            command=self.create_advertiser,
            bg='#27ae60',
            fg='white',
            font=('Arial', 10, 'bold'),
            padx=20,
            pady=5
        ).pack(side='left', padx=5)
        
        tk.Button(
            button_frame, 
            text="Clear Form", 
            command=self.clear_advertiser_form,
            bg='#95a5a6',
            fg='white',
            font=('Arial', 10, 'bold'),
            padx=20,
            pady=5
        ).pack(side='left', padx=5)
        
    def setup_log_tab(self, notebook):
        """Set up the log tab."""
        log_frame = ttk.Frame(notebook)
        notebook.add(log_frame, text="📋 Logs")
        
        # Log section
        log_section = tk.LabelFrame(log_frame, text="Operation Logs", font=('Arial', 12, 'bold'))
        log_section.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Log text area
        self.log_text = scrolledtext.ScrolledText(
            log_section, 
            height=20, 
            width=80,
            font=('Consolas', 9)
        )
        self.log_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Log buttons
        log_button_frame = tk.Frame(log_section)
        log_button_frame.pack(fill='x', padx=5, pady=5)
        
        tk.Button(
            log_button_frame, 
            text="Clear Logs", 
            command=self.clear_logs,
            bg='#e74c3c',
            fg='white',
            font=('Arial', 10, 'bold'),
            padx=15,
            pady=3
        ).pack(side='left', padx=5)
        
        # Initial log message
        self.log_message("🚀 Tkinter GUI started successfully")
        self.log_message("💡 WSL2 + VcXsrv GUI is working perfectly!")
        
    def toggle_auto_generate(self):
        """Toggle auto-generate mode for advertiser fields."""
        if self.auto_generate.get():
            self.name_entry.config(state='disabled')
            self.email_entry.config(state='disabled')
            self.brand_entry.config(state='disabled')
            self.agency_entry.config(state='disabled')
        else:
            self.name_entry.config(state='normal')
            self.email_entry.config(state='normal')
            self.brand_entry.config(state='normal')
            self.agency_entry.config(state='normal')
    
    def log_message(self, message: str):
        """Add a message to the log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        
        self.log_text.insert(tk.END, log_entry)
        self.log_text.see(tk.END)
        self.root.update_idletasks()
    
    def clear_logs(self):
        """Clear the log text area."""
        self.log_text.delete(1.0, tk.END)
        self.log_message("📋 Logs cleared")
    
    def init_database(self):
        """Initialize the database in a separate thread."""
        def run_init():
            try:
                self.log_message("🔄 Initializing database...")
                
                # Call the CLI callback function
                cb_init_db(
                    log_level=self.log_level.get(),
                    db_url=self.db_url.get(),
                    seed=self.seed.get()
                )
                
                self.log_message("✅ Database initialized successfully!")
                messagebox.showinfo("Success", "Database initialized successfully!")
                
            except Exception as e:
                error_msg = f"❌ Error initializing database: {str(e)}"
                self.log_message(error_msg)
                messagebox.showerror("Error", f"Failed to initialize database:\n{str(e)}")
        
        # Run in separate thread to avoid blocking GUI
        thread = threading.Thread(target=run_init)
        thread.daemon = True
        thread.start()
    
    def create_advertiser(self):
        """Create an advertiser in a separate thread."""
        def run_create():
            try:
                self.log_message("🔄 Creating advertiser...")
                
                # Prepare parameters
                name = self.advertiser_name.get() if self.advertiser_name.get().strip() else None
                email = self.advertiser_email.get() if self.advertiser_email.get().strip() else None
                brand = self.advertiser_brand.get() if self.advertiser_brand.get().strip() else None
                agency = self.advertiser_agency.get() if self.advertiser_agency.get().strip() else None
                
                # Call the CLI callback function
                cb_create_advertiser(
                    name=name,
                    email=email,
                    brand=brand,
                    agency=agency,
                    auto=self.auto_generate.get(),
                    log_level="INFO",
                    db_url="sqlite:///ads.db",
                    seed=42
                )
                
                self.log_message("✅ Advertiser created successfully!")
                messagebox.showinfo("Success", "Advertiser created successfully!")
                
                # Clear form if auto-generate was used
                if self.auto_generate.get():
                    self.clear_advertiser_form()
                
            except Exception as e:
                error_msg = f"❌ Error creating advertiser: {str(e)}"
                self.log_message(error_msg)
                messagebox.showerror("Error", f"Failed to create advertiser:\n{str(e)}")
        
        # Run in separate thread to avoid blocking GUI
        thread = threading.Thread(target=run_create)
        thread.daemon = True
        thread.start()
    
    def clear_advertiser_form(self):
        """Clear the advertiser form fields."""
        self.advertiser_name.set("")
        self.advertiser_email.set("")
        self.advertiser_brand.set("")
        self.advertiser_agency.set("")
        self.auto_generate.set(False)
        self.toggle_auto_generate()
        self.log_message("🧹 Advertiser form cleared")
    
    def run(self):
        """Run the GUI application."""
        self.root.mainloop()


def main():
    """Main entry point."""
    try:
        app = CLIGUI()
        app.run()
    except Exception as e:
        print(f"❌ Error starting GUI application: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
