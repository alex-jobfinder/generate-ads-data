#!/bin/bash
# Setup script for WSL2 + VcXsrv GUI support
# Based on the DearPyGui GitHub issue and WSLg documentation

echo "🚀 WSL2 + VcXsrv GUI Setup Script"
echo "=================================="

# Check if we're in WSL2
if ! grep -q Microsoft /proc/version; then
    echo "❌ This script is designed for WSL2. You don't appear to be running WSL2."
    exit 1
fi

echo "✅ Running in WSL2 environment"

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Install required packages
echo ""
echo "📦 Installing required packages..."

# Update package list
sudo apt update

# Install X11 and OpenGL libraries
sudo apt install -y \
    x11-apps \
    xauth \
    libx11-6 \
    libxext6 \
    libxrender1 \
    libxtst6 \
    libxi6 \
    libgl1-mesa-glx \
    libgl1-mesa-dri \
    libglu1-mesa \
    python3-opengl

echo "✅ Required packages installed"

# Check current DISPLAY setting
echo ""
echo "🔍 Checking current DISPLAY setting..."
current_display=$DISPLAY
echo "Current DISPLAY: $current_display"

# Get Windows host IP
windows_ip=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}')
echo "Windows host IP: $windows_ip"

# Set correct DISPLAY for VcXsrv
correct_display="$windows_ip:0.0"
echo "Correct DISPLAY for VcXsrv: $correct_display"

# Check if DISPLAY needs to be updated
if [ "$current_display" != "$correct_display" ]; then
    echo "⚠️  DISPLAY needs to be updated"
    
    # Add to shell profile
    shell_profile=""
    if [ -f "$HOME/.zshrc" ]; then
        shell_profile="$HOME/.zshrc"
    elif [ -f "$HOME/.bashrc" ]; then
        shell_profile="$HOME/.bashrc"
    fi
    
    if [ -n "$shell_profile" ]; then
        echo ""
        echo "📝 Adding DISPLAY export to $shell_profile..."
        
        # Remove any existing DISPLAY exports
        sed -i '/export DISPLAY=/d' "$shell_profile"
        
        # Add correct DISPLAY export
        echo "" >> "$shell_profile"
        echo "# WSL2 + VcXsrv GUI support" >> "$shell_profile"
        echo "export DISPLAY=\$(cat /etc/resolv.conf | grep nameserver | awk '{print \$2}'):0.0" >> "$shell_profile"
        echo "export LIBGL_ALWAYS_INDIRECT=1" >> "$shell_profile"
        
        echo "✅ DISPLAY export added to $shell_profile"
        echo "💡 Run 'source $shell_profile' to apply changes"
    fi
else
    echo "✅ DISPLAY is already set correctly"
fi

# Test X11 connection
echo ""
echo "🧪 Testing X11 connection..."

# Set DISPLAY for this session
export DISPLAY="$correct_display"
export LIBGL_ALWAYS_INDIRECT=1

# Test with xeyes
echo "Testing with xeyes (will run for 3 seconds)..."
timeout 3 xeyes 2>/dev/null &
xeyes_pid=$!
sleep 3
kill $xeyes_pid 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✅ X11 connection test passed"
else
    echo "❌ X11 connection test failed"
    echo "💡 Make sure VcXsrv is running on Windows with these settings:"
    echo "   - Multiple windows"
    echo "   - Disable access control"
    echo "   - Start no client"
fi

# Test Tkinter
echo ""
echo "🧪 Testing Tkinter GUI..."
python3 -c "
import tkinter as tk
import sys
try:
    root = tk.Tk()
    root.title('WSL2 GUI Test')
    root.geometry('300x100')
    label = tk.Label(root, text='WSL2 + VcXsrv GUI Test')
    label.pack(pady=20)
    root.after(2000, root.destroy)
    root.mainloop()
    print('✅ Tkinter GUI test passed')
except Exception as e:
    print(f'❌ Tkinter GUI test failed: {e}')
    sys.exit(1)
"

# Test DearPyGui
echo ""
echo "🧪 Testing DearPyGui..."
python3 -c "
import dearpygui.dearpygui as dpg
import sys
try:
    dpg.create_context()
    dpg.create_viewport(title='DPG Test', width=300, height=200)
    with dpg.window(label='Test'):
        dpg.add_text('DearPyGui Test')
    dpg.setup_dearpygui()
    dpg.show_viewport()
    # Don't start the main loop, just test creation
    dpg.destroy_context()
    print('✅ DearPyGui context creation test passed')
except Exception as e:
    print(f'❌ DearPyGui test failed: {e}')
    print('💡 This is expected - DearPyGui has issues in WSL2')
    print('💡 Use the Tkinter GUI instead: python tkinter_gui.py')
"

echo ""
echo "🎉 Setup complete!"
echo ""
echo "📋 Summary:"
echo "✅ WSL2 environment detected"
echo "✅ Required packages installed"
echo "✅ DISPLAY variable configured"
echo "✅ X11 connection tested"
echo "✅ Tkinter GUI working"
echo "⚠️  DearPyGui has known issues in WSL2"
echo ""
echo "🚀 Next steps:"
echo "1. Make sure VcXsrv is running on Windows"
echo "2. Run: source ~/.zshrc (or ~/.bashrc)"
echo "3. Test GUI: python tkinter_gui.py"
echo "4. Try DearPyGui: python dearpygui_wsl2_test.py"
echo ""
echo "💡 If DearPyGui fails, use the Tkinter GUI - it works perfectly!"
