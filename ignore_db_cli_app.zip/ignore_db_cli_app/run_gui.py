#!/usr/bin/env python3
"""
Launcher script for the CLI GUI application.

This script checks for dependencies and provides helpful error messages
if DearPyGui is not installed.
"""

import sys
import subprocess
import os


def check_dearpygui():
    """Check if DearPyGui is installed."""
    try:
        import dearpygui
        return True, None
    except ImportError as e:
        return False, str(e)


def install_dearpygui():
    """Install DearPyGui using Poetry."""
    try:
        print("📦 Installing dependencies with Poetry...")
        subprocess.check_call(["poetry", "install"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies with Poetry: {e}")
        print("💡 Trying pip fallback...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "dearpygui"])
            print("✅ DearPyGui installed with pip!")
            return True
        except subprocess.CalledProcessError as pip_error:
            print(f"❌ Failed to install DearPyGui with pip: {pip_error}")
            return False


def main():
    """Main launcher function."""
    print("🚀 CLI GUI Launcher")
    print("=" * 50)
    
    # Check if we're in the right directory
    if not os.path.exists("gui_app.py"):
        print("❌ Error: gui_app.py not found in current directory")
        print("💡 Make sure you're running this from the project root directory")
        sys.exit(1)
    
    # Check for DearPyGui
    is_installed, error = check_dearpygui()
    
    if not is_installed:
        print("❌ DearPyGui not found")
        print(f"   Error: {error}")
        print()
        print("🔧 Would you like to install it automatically? (y/n): ", end="")
        
        try:
            response = input().lower().strip()
            if response in ['y', 'yes']:
                if install_dearpygui():
                    print("🔄 Retrying import...")
                    is_installed, _ = check_dearpygui()
                else:
                    print("❌ Installation failed. Please install manually:")
                    print("   pip install dearpygui")
                    sys.exit(1)
            else:
                print("💡 Install manually with:")
                print("   poetry install")
                print("   or: pip install dearpygui")
                sys.exit(1)
        except KeyboardInterrupt:
            print("\n👋 Cancelled by user")
            sys.exit(1)
    
    if is_installed:
        print("✅ DearPyGui found")
        print("🚀 Starting GUI application...")
        print()
        
        # Import and run the GUI app
        try:
            from gui_app import main as gui_main
            gui_main()
        except Exception as e:
            print(f"❌ Error starting GUI application: {e}")
            print("💡 Make sure all CLI dependencies are installed")
            sys.exit(1)
    else:
        print("❌ DearPyGui still not available after installation attempt")
        sys.exit(1)


if __name__ == "__main__":
    main()
