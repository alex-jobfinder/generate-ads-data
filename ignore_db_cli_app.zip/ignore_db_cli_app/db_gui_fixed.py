#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cli_groups.db import cb_init_db, cb_migrate_db

class DBGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🗄️ Database Operations Manager")
        self.root.geometry("700x600")
        self.root.configure(bg='#f0f0f0')
        
        # Configure ttk styles
        self.setup_styles()
        
        # Variables
        self.db_url = tk.StringVar(value="sqlite:///ads.db")
        self.log_level = tk.StringVar(value="INFO")
        self.seed = tk.IntVar(value=42)
        
        self.create_gui()
    
    def setup_styles(self):
        """Configure modern ttk styles."""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure button styles
        style.configure('Modern.TButton',
                       font=('Arial', 10, 'bold'),
                       padding=(15, 8))
        
        style.configure('Success.TButton',
                       font=('Arial', 10, 'bold'),
                       padding=(15, 8))
        
        # Configure label styles
        style.configure('Title.TLabel', 
                       font=('Arial', 16, 'bold'),
                       foreground='#2c3e50')
        
        style.configure('Section.TLabel', 
                       font=('Arial', 11, 'bold'),
                       foreground='#34495e')
    
    def log(self, message):
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
        self.root.update()
    
    def init_db(self):
        try:
            self.log("🔄 Initializing database...")
            self.log(f"   📍 URL: {self.db_url.get()}")
            self.log(f"   📊 Log Level: {self.log_level.get()}")
            self.log(f"   🎲 Seed: {self.seed.get()}")
            
            cb_init_db(
                log_level=self.log_level.get(),
                db_url=self.db_url.get(),
                seed=self.seed.get()
            )
            self.log("✅ Database initialized successfully!")
        except Exception as e:
            self.log(f"❌ Error: {str(e)}")
            messagebox.showerror("Error", str(e))
    
    def migrate_db(self):
        try:
            self.log("🔄 Migrating database...")
            self.log(f"   📍 URL: {self.db_url.get()}")
            self.log(f"   📊 Log Level: {self.log_level.get()}")
            
            cb_migrate_db(
                log_level=self.log_level.get(),
                db_url=self.db_url.get()
            )
            self.log("✅ Database migrated successfully!")
        except Exception as e:
            self.log(f"❌ Error: {str(e)}")
            messagebox.showerror("Error", str(e))
    
    def create_gui(self):
        # Main container
        main_container = tk.Frame(self.root, bg='#f0f0f0', padx=20, pady=20)
        main_container.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_frame = tk.Frame(main_container, bg='#f0f0f0')
        title_frame.pack(fill=tk.X, pady=(0, 20))
        
        ttk.Label(title_frame, text="🗄️ Database Operations Manager", 
                 style='Title.TLabel', background='#f0f0f0').pack()
        
        ttk.Label(title_frame, text="Manage your database initialization and migrations", 
                 font=('Arial', 10), foreground='#7f8c8d', background='#f0f0f0').pack()
        
        # Settings section
        settings_frame = ttk.LabelFrame(main_container, text="⚙️ Configuration", padding=20)
        settings_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Database URL
        url_frame = tk.Frame(settings_frame, bg='white')
        url_frame.pack(fill=tk.X, pady=5)
        ttk.Label(url_frame, text="Database URL:", style='Section.TLabel', background='white').pack(anchor=tk.W)
        ttk.Entry(url_frame, textvariable=self.db_url, width=60).pack(fill=tk.X, pady=(5, 0))
        
        # Options row
        options_frame = tk.Frame(settings_frame, bg='white')
        options_frame.pack(fill=tk.X, pady=10)
        
        # Log Level
        log_frame = tk.Frame(options_frame, bg='white')
        log_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        ttk.Label(log_frame, text="Log Level:", style='Section.TLabel', background='white').pack(anchor=tk.W)
        ttk.Combobox(log_frame, textvariable=self.log_level, 
                    values=["DEBUG", "INFO", "WARNING", "ERROR"], 
                    state="readonly").pack(fill=tk.X, pady=(5, 0))
        
        # Seed
        seed_frame = tk.Frame(options_frame, bg='white')
        seed_frame.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(10, 0))
        ttk.Label(seed_frame, text="Random Seed:", style='Section.TLabel', background='white').pack(anchor=tk.W)
        ttk.Spinbox(seed_frame, from_=1, to=999999, textvariable=self.seed, 
                   width=15).pack(fill=tk.X, pady=(5, 0))
        
        # Buttons section
        buttons_frame = tk.Frame(main_container, bg='#f0f0f0')
        buttons_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(buttons_frame, text="🔧 Operations", style='Section.TLabel', background='#f0f0f0').pack(anchor=tk.W, pady=(0, 10))
        
        button_container = tk.Frame(buttons_frame, bg='#f0f0f0')
        button_container.pack(fill=tk.X)
        
        ttk.Button(button_container, text="🗄️ Initialize Database", 
                  command=self.init_db, style='Modern.TButton').pack(side=tk.LEFT, padx=(0, 15))
        ttk.Button(button_container, text="🔄 Migrate Database", 
                  command=self.migrate_db, style='Success.TButton').pack(side=tk.LEFT)
        
        # Log section
        log_frame = ttk.LabelFrame(main_container, text="📋 Output Log", padding=15)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        # Log text area
        self.log_text = scrolledtext.ScrolledText(
            log_frame, 
            height=12, 
            width=80,
            font=('Consolas', 9),
            bg='#2c3e50',
            fg='#ecf0f1',
            insertbackground='#ecf0f1',
            selectbackground='#3498db',
            relief='flat',
            borderwidth=0
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Initial message
        self.log("🚀 Database Operations GUI ready")
        self.log("💡 Configure your settings above and click the operation buttons")
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = DBGUI()
    app.run()
