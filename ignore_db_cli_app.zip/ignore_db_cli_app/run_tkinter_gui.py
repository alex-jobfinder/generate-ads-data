#!/usr/bin/env python3
"""
Launcher script for the Tkinter GUI application.

This script checks for Tkinter and provides helpful error messages
if it's not available.
"""

import sys
import subprocess
import os


def check_tkinter():
    """Check if Tkinter is available."""
    try:
        import tkinter
        return True, None
    except ImportError as e:
        return False, str(e)


def install_tkinter():
    """Install Tkinter using apt."""
    try:
        print("📦 Installing Tkinter...")
        subprocess.check_call(["sudo", "apt", "install", "-y", "python3-tk"])
        print("✅ Tkinter installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install Tkinter: {e}")
        return False


def main():
    """Main launcher function."""
    print("🖥️  Tkinter GUI Launcher")
    print("=" * 50)
    
    # Check if we're in the right directory
    if not os.path.exists("tkinter_gui.py"):
        print("❌ Error: tkinter_gui.py not found in current directory")
        print("💡 Make sure you're running this from the project root directory")
        sys.exit(1)
    
    # Check for Tkinter
    is_installed, error = check_tkinter()
    
    if not is_installed:
        print("❌ Tkinter not found")
        print(f"   Error: {error}")
        print()
        print("🔧 Would you like to install it automatically? (y/n): ", end="")
        
        try:
            response = input().lower().strip()
            if response in ['y', 'yes']:
                if install_tkinter():
                    print("🔄 Retrying import...")
                    is_installed, _ = check_tkinter()
                else:
                    print("❌ Installation failed. Please install manually:")
                    print("   sudo apt install python3-tk")
                    sys.exit(1)
            else:
                print("💡 Install manually with:")
                print("   sudo apt install python3-tk")
                sys.exit(1)
        except KeyboardInterrupt:
            print("\n👋 Cancelled by user")
            sys.exit(1)
    
    if is_installed:
        print("✅ Tkinter found")
        print("🚀 Starting Tkinter GUI...")
        print("💡 Make sure VcXsrv is running on Windows!")
        print()
        
        # Import and run the GUI app
        try:
            from tkinter_gui import main as gui_main
            gui_main()
        except Exception as e:
            print(f"❌ Error starting GUI application: {e}")
            print("💡 Make sure all CLI dependencies are installed")
            sys.exit(1)
    else:
        print("❌ Tkinter still not available after installation attempt")
        sys.exit(1)


if __name__ == "__main__":
    main()
