import tkinter as tk
from tkinter import ttk

def create_gui():
    root = tk.Tk()
    root.title("Custom Title")
    root.geometry("600x600")
    
    # Create a simple GUI similar to DearPyGui demo
    frame = ttk.Frame(root, padding="10")
    frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
    
    # Add some widgets
    ttk.Label(frame, text="Hello from Tkinter!").grid(row=0, column=0, pady=5)
    ttk.Button(frame, text="Click me!", command=lambda: print("Button clicked!")).grid(row=1, column=0, pady=5)
    
    # Add a text widget
    text_widget = tk.Text(frame, height=10, width=50)
    text_widget.grid(row=2, column=0, pady=5)
    text_widget.insert(tk.END, "This is a working GUI alternative to DearPyGui on WSL2!")
    
    # Add a progress bar
    progress = ttk.Progressbar(frame, mode='indeterminate')
    progress.grid(row=3, column=0, pady=5, sticky=(tk.W, tk.E))
    progress.start()
    
    root.mainloop()

if __name__ == "__main__":
    create_gui()
