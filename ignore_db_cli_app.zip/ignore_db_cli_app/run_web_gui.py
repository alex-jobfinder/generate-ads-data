#!/usr/bin/env python3
"""
Launcher script for the Web GUI application.

This script checks for Flask dependencies and provides helpful error messages
if they are not installed.
"""

import sys
import subprocess
import os
import webbrowser
import time
import threading


def check_flask():
    """Check if Flask is installed."""
    try:
        import flask
        import flask_cors
        return True, None
    except ImportError as e:
        return False, str(e)


def install_flask():
    """Install Flask using Poetry."""
    try:
        print("📦 Installing Flask dependencies with Poetry...")
        subprocess.check_call(["poetry", "install"])
        print("✅ Dependencies installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install dependencies with Poetry: {e}")
        print("💡 Trying pip fallback...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "flask-cors"])
            print("✅ Flask installed with pip!")
            return True
        except subprocess.CalledProcessError as pip_error:
            print(f"❌ Failed to install Flask with pip: {pip_error}")
            return False


def open_browser():
    """Open browser after a short delay."""
    time.sleep(2)
    try:
        webbrowser.open('http://localhost:8080')
        print("🌐 Browser opened automatically")
    except Exception:
        print("💡 Please open your browser manually and go to: http://localhost:8080")


def main():
    """Main launcher function."""
    print("🌐 CLI Web GUI Launcher")
    print("=" * 50)
    
    # Check if we're in the right directory
    if not os.path.exists("web_gui.py"):
        print("❌ Error: web_gui.py not found in current directory")
        print("💡 Make sure you're running this from the project root directory")
        sys.exit(1)
    
    # Check for Flask
    is_installed, error = check_flask()
    
    if not is_installed:
        print("❌ Flask not found")
        print(f"   Error: {error}")
        print()
        print("🔧 Would you like to install it automatically? (y/n): ", end="")
        
        try:
            response = input().lower().strip()
            if response in ['y', 'yes']:
                if install_flask():
                    print("🔄 Retrying import...")
                    is_installed, _ = check_flask()
                else:
                    print("❌ Installation failed. Please install manually:")
                    print("   poetry install")
                    print("   or: pip install flask flask-cors")
                    sys.exit(1)
            else:
                print("💡 Install manually with:")
                print("   poetry install")
                print("   or: pip install flask flask-cors")
                sys.exit(1)
        except KeyboardInterrupt:
            print("\n👋 Cancelled by user")
            sys.exit(1)
    
    if is_installed:
        print("✅ Flask found")
        print("🚀 Starting Web GUI...")
        print()
        
        # Start browser opening in background
        browser_thread = threading.Thread(target=open_browser)
        browser_thread.daemon = True
        browser_thread.start()
        
        # Import and run the web GUI
        try:
            from web_gui import main as web_gui_main
            web_gui_main()
        except Exception as e:
            print(f"❌ Error starting Web GUI: {e}")
            print("💡 Make sure all CLI dependencies are installed")
            sys.exit(1)
    else:
        print("❌ Flask still not available after installation attempt")
        sys.exit(1)


if __name__ == "__main__":
    main()
