#!/usr/bin/env python3
"""
Standalone, minimal, complete and verifiable example for DearPyGui in WSL2 + VcXsrv.

This is specifically designed to work with:
- WSL2 on Windows 10
- VcXsrv X Server
- DearPyGui 1.10.0+

Based on the GitHub issue: https://github.com/hoffstadt/DearPyGui/issues/1234
"""

# WSL2 was updated to make the display forwarding easier. You no longer need to set the Host IP through your .bashrc or .profile. Make sure echo $DISPLAY returns :0, otherwise hunt down where you override the DISPLAY variable. See https://github.com/microsoft/wslg/wiki/Diagnosing-%22cannot-open-display%22-type-issues-with-WSLg#display-environment-variable

import os
import sys
import dearpygui.dearpygui as dpg

def check_environment():
    """Check if the environment is properly configured for WSL2 + VcXsrv."""
    print("🔍 Checking WSL2 + VcXsrv environment...")
    
    # Check DISPLAY variable
    display = os.environ.get('DISPLAY')
    print(f"DISPLAY: {display}")
    
    if not display:
        print("❌ DISPLAY environment variable not set!")
        print("💡 Add this to your ~/.zshrc or ~/.bashrc:")
        print("   export DISPLAY=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}'):0.0")
        return False
    
    if display == ":0":
        print("⚠️  DISPLAY is set to :0 (WSLg style)")
        print("💡 For VcXsrv, it should be: <windows_ip>:0.0")
        print("💡 Try: export DISPLAY=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}'):0.0")
        return False
    
    if not display.endswith(":0.0"):
        print("⚠️  DISPLAY should end with :0.0 for VcXsrv")
        return False
    
    print("✅ DISPLAY variable looks correct for VcXsrv")
    
    # Check if X11 socket exists
    x11_socket = "/tmp/.X11-unix/X0"
    if os.path.exists(x11_socket):
        print("✅ X11 socket found")
    else:
        print("⚠️  X11 socket not found at /tmp/.X11-unix/X0")
        print("💡 Make sure VcXsrv is running on Windows")
    
    # Check OpenGL libraries
    try:
        import OpenGL
        print("✅ OpenGL libraries available")
    except ImportError:
        print("⚠️  OpenGL libraries not found")
        print("💡 Install with: sudo apt install python3-opengl")
    
    return True

def create_minimal_dpg_app():
    """Create a minimal DearPyGui application."""
    print("🚀 Creating minimal DearPyGui application...")
    
    # Create DearPyGui context
    dpg.create_context()
    
    # Create viewport with specific settings for WSL2
    dpg.create_viewport(
        title='DearPyGui WSL2 + VcXsrv Test',
        width=600,
        height=400,
        resizable=True
    )
    
    # Create a simple window
    with dpg.window(label="WSL2 Test Window", width=580, height=350):
        dpg.add_text("🎉 DearPyGui is working in WSL2 + VcXsrv!")
        dpg.add_separator()
        
        dpg.add_text("Environment Info:")
        dpg.add_text(f"DISPLAY: {os.environ.get('DISPLAY', 'Not set')}")
        dpg.add_text(f"Python: {sys.version}")
        try:
            dpg.add_text(f"DearPyGui: {dpg.__version__}")
        except AttributeError:
            dpg.add_text("DearPyGui: Version info not available")
        
        dpg.add_separator()
        
        dpg.add_text("Test Controls:")
        dpg.add_button(label="Test Button", callback=lambda: print("Button clicked!"))
        dpg.add_input_text(label="Test Input", default_value="Type something...")
        dpg.add_slider_float(label="Test Slider", default_value=0.5, min_value=0.0, max_value=1.0)
        
        dpg.add_separator()
        
        dpg.add_text("If you can see this window, DearPyGui is working! 🎊")
    
    # Setup DearPyGui
    dpg.setup_dearpygui()
    
    # Show viewport
    dpg.show_viewport()
    
    print("✅ DearPyGui application created successfully!")
    print("🖥️  Look for the window on your Windows desktop (via VcXsrv)")
    print("🛑 Press Ctrl+C to exit")
    
    # Start the GUI loop
    try:
        dpg.start_dearpygui()
    except KeyboardInterrupt:
        print("\n👋 Application stopped by user")
    finally:
        # Cleanup
        dpg.destroy_context()
        print("🧹 DearPyGui context destroyed")

def main():
    """Main entry point."""
    print("=" * 60)
    print("DearPyGui WSL2 + VcXsrv Test")
    print("=" * 60)
    
    # Check environment first
    if not check_environment():
        print("\n❌ Environment check failed!")
        print("💡 Please fix the issues above and try again.")
        sys.exit(1)
    
    print("\n✅ Environment check passed!")
    
    # Try to create the DearPyGui application
    try:
        create_minimal_dpg_app()
    except Exception as e:
        print(f"\n❌ Error creating DearPyGui application: {e}")
        print("\n🔧 Troubleshooting tips:")
        print("1. Make sure VcXsrv is running on Windows")
        print("2. Check that DISPLAY variable is set correctly")
        print("3. Try running: xeyes (should show a simple GUI)")
        print("4. Install missing libraries: sudo apt install python3-opengl")
        print("5. Try the Tkinter GUI instead: python tkinter_gui.py")
        sys.exit(1)

if __name__ == "__main__":
    main()
