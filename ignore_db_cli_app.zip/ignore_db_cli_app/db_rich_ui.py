#!/usr/bin/env python3
"""
Rich UI for Database CLI Commands
A beautiful terminal interface for database operations.
"""

import sys
import os
from typing import Optional

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.layout import Layout
from rich.live import Live
from rich.text import Text
from rich.align import Align
from rich import box

# Import CLI functions
from cli_groups.db import cb_init_db, cb_migrate_db

class DatabaseRichUI:
    def __init__(self):
        self.console = Console()
        self.db_url = "sqlite:///ads.db"
        self.log_level = "INFO"
        self.seed = 42
        
    def show_welcome(self):
        """Display welcome screen."""
        welcome_text = Text()
        welcome_text.append("🗄️ Database Operations Manager\n", style="bold blue")
        welcome_text.append("Manage your database initialization and migrations\n", style="dim")
        welcome_text.append("with a beautiful terminal interface", style="dim")
        
        panel = Panel(
            Align.center(welcome_text),
            title="[bold green]Welcome[/bold green]",
            border_style="green",
            padding=(1, 2)
        )
        self.console.print(panel)
        self.console.print()
    
    def show_configuration(self):
        """Display current configuration."""
        table = Table(title="⚙️ Current Configuration", box=box.ROUNDED)
        table.add_column("Setting", style="cyan", no_wrap=True)
        table.add_column("Value", style="green")
        
        table.add_row("Database URL", self.db_url)
        table.add_row("Log Level", self.log_level)
        table.add_row("Random Seed", str(self.seed))
        
        self.console.print(table)
        self.console.print()
    
    def configure_settings(self):
        """Allow user to configure settings."""
        self.console.print(Panel("⚙️ Configuration Settings", style="blue"))
        
        # Database URL
        new_db_url = Prompt.ask(
            "Database URL", 
            default=self.db_url,
            show_default=True
        )
        self.db_url = new_db_url
        
        # Log Level
        log_levels = ["DEBUG", "INFO", "WARNING", "ERROR"]
        self.console.print("\nAvailable log levels:")
        for i, level in enumerate(log_levels, 1):
            self.console.print(f"  {i}. {level}")
        
        while True:
            try:
                choice = IntPrompt.ask(
                    f"Select log level (1-{len(log_levels)})", 
                    default=log_levels.index(self.log_level) + 1
                )
                if 1 <= choice <= len(log_levels):
                    self.log_level = log_levels[choice - 1]
                    break
                else:
                    self.console.print("[red]Invalid choice. Please try again.[/red]")
            except ValueError:
                self.console.print("[red]Please enter a valid number.[/red]")
        
        # Seed
        self.seed = IntPrompt.ask(
            "Random seed", 
            default=self.seed,
            show_default=True
        )
        
        self.console.print("\n[green]✅ Configuration updated![/green]")
        self.console.print()
    
    def init_database(self):
        """Initialize database with Rich UI."""
        self.console.print(Panel("🗄️ Database Initialization", style="blue"))
        
        # Show what will be done
        table = Table(title="Initialization Settings", box=box.ROUNDED)
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Database URL", self.db_url)
        table.add_row("Log Level", self.log_level)
        table.add_row("Random Seed", str(self.seed))
        
        self.console.print(table)
        self.console.print()
        
        if not Confirm.ask("Proceed with database initialization?"):
            self.console.print("[yellow]Operation cancelled.[/yellow]")
            return
        
        # Execute with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
        ) as progress:
            task = progress.add_task("Initializing database...", total=None)
            
            try:
                cb_init_db(
                    log_level=self.log_level,
                    db_url=self.db_url,
                    seed=self.seed
                )
                progress.update(task, description="✅ Database initialized successfully!")
                
                self.console.print(Panel(
                    "🎉 Database initialization completed successfully!\n"
                    f"Database: {self.db_url}\n"
                    f"Log Level: {self.log_level}\n"
                    f"Seed: {self.seed}",
                    title="[bold green]Success[/bold green]",
                    border_style="green"
                ))
                
            except Exception as e:
                progress.update(task, description="❌ Database initialization failed!")
                self.console.print(Panel(
                    f"❌ Error: {str(e)}",
                    title="[bold red]Error[/bold red]",
                    border_style="red"
                ))
    
    def migrate_database(self):
        """Migrate database with Rich UI."""
        self.console.print(Panel("🔄 Database Migration", style="blue"))
        
        # Show what will be done
        table = Table(title="Migration Settings", box=box.ROUNDED)
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Database URL", self.db_url)
        table.add_row("Log Level", self.log_level)
        
        self.console.print(table)
        self.console.print()
        
        if not Confirm.ask("Proceed with database migration?"):
            self.console.print("[yellow]Operation cancelled.[/yellow]")
            return
        
        # Execute with progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console,
        ) as progress:
            task = progress.add_task("Applying database migrations...", total=None)
            
            try:
                cb_migrate_db(
                    log_level=self.log_level,
                    db_url=self.db_url
                )
                progress.update(task, description="✅ Database migrations completed!")
                
                self.console.print(Panel(
                    "🎉 Database migration completed successfully!\n"
                    f"Database: {self.db_url}\n"
                    f"Log Level: {self.log_level}",
                    title="[bold green]Success[/bold green]",
                    border_style="green"
                ))
                
            except Exception as e:
                progress.update(task, description="❌ Database migration failed!")
                self.console.print(Panel(
                    f"❌ Error: {str(e)}",
                    title="[bold red]Error[/bold red]",
                    border_style="red"
                ))
    
    def show_main_menu(self):
        """Display main menu and handle user choices."""
        while True:
            self.console.clear()
            self.show_welcome()
            self.show_configuration()
            
            # Main menu
            menu_table = Table(title="📋 Main Menu", box=box.ROUNDED)
            menu_table.add_column("Option", style="cyan", no_wrap=True)
            menu_table.add_column("Description", style="white")
            
            menu_table.add_row("1", "⚙️ Configure Settings")
            menu_table.add_row("2", "🗄️ Initialize Database")
            menu_table.add_row("3", "🔄 Migrate Database")
            menu_table.add_row("4", "📊 Show Configuration")
            menu_table.add_row("5", "❌ Exit")
            
            self.console.print(menu_table)
            self.console.print()
            
            choice = Prompt.ask(
                "Select an option", 
                choices=["1", "2", "3", "4", "5"],
                default="1"
            )
            
            if choice == "1":
                self.configure_settings()
            elif choice == "2":
                self.init_database()
            elif choice == "3":
                self.migrate_database()
            elif choice == "4":
                self.show_configuration()
                Prompt.ask("\nPress Enter to continue")
            elif choice == "5":
                if Confirm.ask("Are you sure you want to exit?"):
                    self.console.print(Panel(
                        "👋 Thank you for using Database Operations Manager!",
                        title="[bold blue]Goodbye[/bold blue]",
                        border_style="blue"
                    ))
                    break
    
    def run(self):
        """Run the Rich UI application."""
        try:
            self.show_main_menu()
        except KeyboardInterrupt:
            self.console.print("\n[yellow]Operation cancelled by user.[/yellow]")
        except Exception as e:
            self.console.print(f"\n[red]Unexpected error: {str(e)}[/red]")

def main():
    """Main entry point."""
    try:
        app = DatabaseRichUI()
        app.run()
    except ImportError as e:
        print("❌ Error: Rich not installed")
        print("💡 Install it with: pip install rich")
        print(f"   Import error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error starting Rich UI application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
