# CLI GUI Application

A simple DearPyGui application that provides a graphical interface for the two most common CLI operations:

1. **Initialize Database** - Set up a fresh database
2. **Create Advertiser** - Create new advertisers with auto-generation or manual input

## Installation

### Using Poetry (Recommended)
1. Install all dependencies with Poetry:
   ```bash
   poetry install
   ```

### Using pip
1. Install DearPyGui directly:
   ```bash
   pip install dearpygui
   ```

## Usage

### Using Poetry (Recommended)
Run the GUI application with Poetry:
```bash
poetry run python gui_app.py
```

Or use the launcher script:
```bash
poetry run python run_gui.py
```

### Using pip
Run the GUI application directly:
```bash
python gui_app.py
```

Or use the launcher script:
```bash
python run_gui.py
```

## Features

### 🗄️ Database Operations
- **Initialize Database**: Set up a fresh database with configurable options
- **Database URL**: Defaults to `sqlite:///ads.db`
- **Log Level**: Choose from DEBUG, INFO, WARNING, ERROR
- **Seed**: Random seed for reproducible generation

### 👤 Advertiser Operations
- **Auto-generate**: Checkbox to automatically generate realistic advertiser data
- **Manual Input**: Fill in name, email, brand, and agency manually
- **Clear Form**: Reset all advertiser fields

### 📋 Output Log
- Real-time feedback on operations
- Scrollable log with last 100 messages
- Clear log functionality

## How It Works

The GUI application directly calls the CLI callback functions:
- `cb_init_db()` from `cli_groups.db`
- `cb_create_advertiser()` from `cli_groups.campaign`

This ensures the GUI uses the exact same logic as the command-line interface.

## Screenshots

The application provides:
- Collapsible sections for organized interface
- Input fields with real-time updates
- Output log for operation feedback
- Clean, modern DearPyGui interface

## Troubleshooting

### Import Errors
If you get import errors, make sure you're running from the project root directory and all CLI dependencies are installed.

### Database Errors
Ensure you have the required database utilities and models available in your Python path.

### GUI Not Starting
Make sure DearPyGui is properly installed:
```bash
pip install --upgrade dearpygui
```
