# WSL2 GUI Setup Guide

WSL2 doesn't support GUI applications by default. Here are several solutions to run the GUI app:

## Option 1: WSLg (Recommended - Windows 11)

If you're on Windows 11, WSLg is built-in:

1. **Check if WSLg is available:**
   ```bash
   echo $DISPLAY
   ```

2. **If DISPLAY is empty, update WSL:**
   ```bash
   wsl --update
   wsl --shutdown
   # Restart WSL
   ```

3. **Run the GUI:**
   ```bash
   poetry run python gui_app.py
   ```

## Option 2: X11 Forwarding (Windows 10/11)

### Install VcXsrv (X Server for Windows)

1. **Download and install VcXsrv:**
   - Download from: https://sourceforge.net/projects/vcxsrv/
   - Install with default settings

2. **Configure VcXsrv:**
   - Start "XLaunch"
   - Select "Multiple windows"
   - Check "Disable access control"
   - Start the server

3. **Set up WSL2:**
```bash
# Add to ~/.bashrc or ~/.zshrc
export DISPLAY=$(cat /etc/resolv.conf | grep nameserver | awk '{print $2}'):0.0
export LIBGL_ALWAYS_INDIRECT=1

# Reload shell
source ~/.bashrc
source ~/.zshrc
```

4. **Test the setup:**
```bash
poetry run python gui_app.py
```

## Option 3: Web-Based GUI (No X11 needed)

I'll create a web-based alternative that works in any browser:

```bash
# Run the web GUI
poetry run python web_gui.py
```

Then open http://localhost:8080 in your browser.

## Option 4: Use Windows Terminal with GUI

Run the GUI directly in Windows:

1. **Install Python on Windows**
2. **Install dependencies:**
   ```cmd
   pip install dearpygui
   ```
3. **Run from Windows:**
   ```cmd
   python gui_app.py
   ```

## Troubleshooting

### Common Issues:

1. **"Display not set" error:**
   - Make sure VcXsrv is running
   - Check DISPLAY variable: `echo $DISPLAY`

2. **"Connection refused" error:**
   - Restart VcXsrv
   - Check Windows Firewall settings

3. **Segmentation fault:**
   - Try Option 3 (Web GUI) instead
   - Or use Windows native Python

### Quick Test:
```bash
# Test if X11 is working
sudo apt update && sudo apt install -y x11-apps
xeyes  # Should show a simple GUI app
```
